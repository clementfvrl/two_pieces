#include <stdio.h>
#include "game.h"

int main() {
    printf("Bienvenue dans le jeu SIMS One Piece !\n");
    printf("Chargement du jeu...\n");

    startGame(); // Fonction principale qui gère la boucle du jeu

    return 0;
}